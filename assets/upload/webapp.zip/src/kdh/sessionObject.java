package kdh;

import java.io.Serializable;
public class sessionObject implements Serializable{
	private static final long serialVersionUID = 1234567L;
	private int cnt;
	
	public sessionObject(){
		cnt = new Integer(1);
	}
	
	public int getCnt(){
		return cnt;
	}
	
	public void incCnt(){
		cnt++;
	}
}
